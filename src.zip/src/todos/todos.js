import { createSlice } from "@reduxjs/toolkit";
import { getUser } from "../api/todoApi";

const todos = createSlice ( {
    name : "todos",
    initialState : {
        infoData : []
    },
    reducers : {},
    extraReducers : ( builder ) => {
        builder.addCase ( getUser . fulfilled , ( state , action ) => {
            state . infoData = action.payload
        })
    }
})

export const { infoData } = todos.actions

export default todos.reducer
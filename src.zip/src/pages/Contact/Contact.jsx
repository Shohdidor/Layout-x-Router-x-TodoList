import React from 'react'
import { useSelector } from 'react-redux'

function Contact() {
  const data = useSelector ((store) => store.todos.infoData )
  return (
    <>
    {data.map((elem)=>{
      return(
        <div key={elem.id}>
          <h1>
            {elem.name}
          </h1>
        </div>
      )
    })}
    </>
  )
}

export default Contact
import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
let api = "http://localhost:3000/data"

export const getUser = createAsyncThunk ( "todos/getUser" , async function () {
    try {
        let { data } = await axios.get(api)
    } catch (error) {
        console.log(error);
    }
})